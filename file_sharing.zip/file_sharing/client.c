#include "header.h"

struct text
{
    char word[SIZE];
    int count;
    int seq;
};

void Receive_the_file_from_server();
void send_the_file_to_server();
void get_time_for_filename(char *);

int main()
{
    while (1)
    {
        int option;
        printf("1 ==> sender.\n2 ==> Receiver.\n3 ==> Exit.\n");
        printf("Enter the option: ");
        scanf("%d", &option);

        if (option == 1)
        {
            send_the_file_to_server();
        }

        else if (option == 2)
        {
            Receive_the_file_from_server();
        }

        else
        {
            printf("Thank you...!\n");
            return 0;
        }
    }
}

void send_the_file_to_server()
{
    char name[20];
    printf("Enter the filename: ");
    scanf("%s", name);

    char filetype[6];
    int n = strlen(name);
    int j = 0;
    for (int i = 0; i < n; i++)
    {
        if (name[i] == '.')
        {
            while (i < n)
            {
                filetype[j] = name[i];
                j++;
                i++;
            }
            filetype[j] = '\0';
            break;
        }
    }

    int send = socket(AF_INET, SOCK_DGRAM, 0);
    if (send == -1)
    {
        perror("Open socket: ");
        return;
    }
    struct sockaddr_in client_info;
    socklen_t len = sizeof(client_info);

    client_info.sin_family = AF_INET;
    client_info.sin_port = htons(PORT);
    client_info.sin_addr.s_addr = inet_addr("127.0.0.1");

    sendto(send, filetype, sizeof(filetype) + 1, 0, (struct sockaddr *)&client_info, len);

    sleep(3);

    int file = open(name, O_RDONLY);
    if (file == -1)
    {
        printf("File can't be open.\n");
        return;
    }
    struct text data;

    // lseek(file, 0, SEEK_SET);
    int r = 1;
    int sequence = 0;
    while (r > 0)
    {
        r = read(file, data.word, SIZE);
        data.count = r;
        data.seq = sequence;
        sendto(send, &data, sizeof(data), 0, (struct sockaddr *)&client_info, len);

        int ack;
        recvfrom(send, &ack, sizeof(int), 0, NULL, NULL);

        if (ack == sequence)
        {
            sequence++;
        }

        if (r == 0)
        {
            printf("File send to server succesfully...!\n");
            break;
        }
    }

    close(file);
    close(send);
}

void Receive_the_file_from_server()
{
    char name[25];
    get_time_for_filename(name);
    char type[6];
    char title[10] = "Receive";
    strcat(name, title);
    printf("Before file name: %s\n", name);

    int rece = socket(AF_INET, SOCK_DGRAM, 0);
    if (rece == -1)
    {
        perror("Receiver: ");
        return;
    }

    struct sockaddr_in client_info, server_info;
    socklen_t len = sizeof(client_info);

    server_info.sin_family = AF_INET;
    server_info.sin_port = htons(PORT);
    server_info.sin_addr.s_addr = inet_addr("127.0.0.1");

    if (bind(rece, (struct sockaddr *)&server_info, sizeof(server_info)) == -1)
    {
        perror("Bind: ");
        return;
    }

    recvfrom(rece, &type, sizeof(type), 0, (struct sockaddr *)&client_info, &len);

    strcat(name, type);

    printf("File name: %s\n", name);

    int file = open(name, O_CREAT | O_WRONLY, S_IRUSR | S_IWUSR | S_IROTH | S_IRGRP);

    if (file == -1)
    {
        perror("Server file: ");
        return;
    }
    struct text details;

    int w = 1;
    int sequence = 0;
    while (w > 0)
    {

        recvfrom(rece, &details, sizeof(details), 0, (struct sockaddr *)&client_info, &len);

        w = details.count;
        if (details.seq == sequence)
        {
            // details.word[w] = '\0';
            write(file, details.word, w);
            sequence++;
        }

        sendto(rece, &details.seq, sizeof(int), 0, (struct sockaddr *)&client_info, len);

        if (w == 0)
        {
            printf("Content copied succesfully...!\n");
            break;
        }
    }

    close(file);
    close(rece);
}

void get_time_for_filename(char name[25])
{
    struct timeval my_time;
    char hour[3];
    char min[3];
    char sec[3];

    setenv("TZ", "Asia/Kolkata", 1);
    tzset();

    gettimeofday(&my_time, NULL);

    struct tm *now = localtime(&my_time.tv_sec);

    sprintf(hour, "%02d", now->tm_hour);
    sprintf(min, "%02d", now->tm_min);
    sprintf(sec, "%02d", now->tm_sec);

    strcpy(name, hour);
    strcat(name, ":");
    strcat(name, min);
    strcat(name, ":");
    strcat(name, sec);
    strcat(name, "_");
    return;
}