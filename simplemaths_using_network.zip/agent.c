#include <stdio.h>
#include <sys/socket.h>
#include <string.h>
#include <netinet/in.h>
#include <netinet/ip.h>
#include <arpa/inet.h>

int main()
{
    char operat[10];

    int sock_id = socket(AF_INET, SOCK_STREAM, 0);

    if (sock_id == -1)
    {
        perror("server: ");
        return -1;
    }

    struct sockaddr_in server_info;
    memset(&server_info, 0, sizeof(server_info));

    server_info.sin_family = AF_INET;
    server_info.sin_port = htons(1026);
    server_info.sin_addr.s_addr = inet_addr("127.0.0.1");

    bind(sock_id, (struct sockaddr *)&server_info, sizeof(server_info));

    listen(sock_id, 7);

    int join = accept(sock_id, NULL, NULL);
    if (join == -1)
    {
        perror("Coneet server: ");
        return -1;
    }

    recv(join, operat, sizeof(operat), 0);

    printf("%s \n", operat);

    int n = strlen(operat);
    int ports[n];

    for (int i = 0; i < n; i++)
    {
        if (operat[i] == '+')
        {
            ports[i] = 2001;
        }
        else if (operat[i] == '-')
        {
            ports[i] = 2002;
        }
        else if (operat[i] == '*')
        {
            ports[i] = 2003;
        }
        else if (operat[i] == '/')
        {
            ports[i] = 2004;
        }
        else if (operat[i] == '%')
        {
            ports[i] = 2005;
        }
        else
        {
            ports[i] = 0;
        }
    }

    send(join, ports, sizeof(int) * n, 0);

    printf("ports sended to cliend succesfully...!\n");

    return 0;
}