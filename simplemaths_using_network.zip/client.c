#include <stdio.h>
#include <string.h>
#include <sys/socket.h>
#include <netinet/ip.h>
#include <netinet/in.h>
#include <arpa/inet.h>

void convert_string_number_and_operator(char *input, char *operator, int *values, int *size)
{
    int n = strlen(input);
    int ch = 0;

    for (int i = 0; i < n; i++)
    {
        if (input[i] == '+' || input[i] == '-' || input[i] == '*' || input[i] == '/' || input[i] == '%')
        {
            operator[ch] = input[i];
            ch++;
        }
    }
    operator[ch] = '\0';

    for (int i = 0; i < n; i++)
    {
        if (input[i] >= '0' && input[i] <= '9')
        {
            values[*size] = (values[*size] * 10) + (input[i] - '0');

            if (input[i + 1] == ' ' || input[i + 1] == '\0')
            {
                (*size)++;
            }
        }
    }

    //*size -= 1;
}

void sum_of_the_elements(int size, int values[], int port)
{
    int new_value[size + 1];
    new_value[0] = size;

    for (int i = 1; i <= size; i++)
    {
        new_value[i] = values[i - 1];
    }

    int id = socket(AF_INET, SOCK_STREAM, 0);
    if (id == -1)
    {
        perror("sum server: ");
        return;
    }
    struct sockaddr_in server_info;
    memset(&server_info, 0, sizeof(server_info));

    server_info.sin_family = AF_INET;
    server_info.sin_port = htons(port);
    server_info.sin_addr.s_addr = inet_addr("127.0.0.1");

    connect(id, (struct sockaddr *)&server_info, sizeof(server_info));

    send(id, new_value, sizeof(int) * (size + 1), 0);

    int sum = 0;
    recv(id, &sum, sizeof(int), 0);

    printf("Sum of values: %d\n", sum);

    // printf("values are: ");
    // for (int i = 0; i <= size; i++)
    // {
    //     printf("%d ", new_value[i]);
    // }

    // int client = socket(AF_INET, SOCK_STREAM, 0) if ()
}

void sub_of_the_elements(int size, int values[], int port)
{
    int new_value[size + 1];
    new_value[0] = size;

    for (int i = 1; i <= size; i++)
    {
        new_value[i] = values[i - 1];
    }

    int id = socket(AF_INET, SOCK_STREAM, 0);
    if (id == -1)
    {
        perror("sum server: ");
        return;
    }
    struct sockaddr_in server_info;
    memset(&server_info, 0, sizeof(server_info));

    server_info.sin_family = AF_INET;
    server_info.sin_port = htons(port);
    server_info.sin_addr.s_addr = inet_addr("127.0.0.1");

    connect(id, (struct sockaddr *)&server_info, sizeof(server_info));

    send(id, new_value, sizeof(int) * (size + 1), 0);

    int sub = 0;
    recv(id, &sub, sizeof(int), 0);

    // printf("values are: ");
    // for (int i = 0; i <= size; i++)
    // {
    //     printf("%d ", new_value[i]);
    // }

    printf("Substract of values: %d\n", sub);
}

void mul_of_the_elements(int size, int values[], int port)
{
    int new_value[size + 1];
    new_value[0] = size;

    for (int i = 1; i <= size; i++)
    {
        new_value[i] = values[i - 1];
    }

    int id = socket(AF_INET, SOCK_STREAM, 0);
    if (id == -1)
    {
        perror("sum server: ");
        return;
    }
    struct sockaddr_in server_info;
    memset(&server_info, 0, sizeof(server_info));

    server_info.sin_family = AF_INET;
    server_info.sin_port = htons(port);
    server_info.sin_addr.s_addr = inet_addr("127.0.0.1");

    connect(id, (struct sockaddr *)&server_info, sizeof(server_info));

    send(id, new_value, sizeof(int) * (size + 1), 0);

    int mul = 0;
    recv(id, &mul, sizeof(int), 0);

    // printf("values are: ");
    // for (int i = 0; i <= size; i++)
    // {
    //     printf("%d ", new_value[i]);
    // }

    printf("Multiply of values: %d\n", mul);
}

void div_of_the_elements(int size, int values[], int port)
{
    int new_value[size + 1];
    new_value[0] = size;

    for (int i = 1; i <= size; i++)
    {
        new_value[i] = values[i - 1];
    }

    int id = socket(AF_INET, SOCK_STREAM, 0);
    if (id == -1)
    {
        perror("sum server: ");
        return;
    }
    struct sockaddr_in server_info;
    memset(&server_info, 0, sizeof(server_info));

    server_info.sin_family = AF_INET;
    server_info.sin_port = htons(port);
    server_info.sin_addr.s_addr = inet_addr("127.0.0.1");

    connect(id, (struct sockaddr *)&server_info, sizeof(server_info));

    send(id, new_value, sizeof(int) * (size + 1), 0);

    int div = 0;
    recv(id, &div, sizeof(int), 0);

    // printf("values are: ");
    // for (int i = 0; i <= size; i++)
    // {
    //     printf("%d ", new_value[i]);
    // }

    printf("Divided of values: %d\n", div);
}

void mod_of_the_elements(int size, int values[], int port)
{
    int new_value[size + 1];
    new_value[0] = size;

    for (int i = 1; i <= size; i++)
    {
        new_value[i] = values[i - 1];
    }

    int id = socket(AF_INET, SOCK_STREAM, 0);
    if (id == -1)
    {
        perror("sum server: ");
        return;
    }
    struct sockaddr_in server_info;
    memset(&server_info, 0, sizeof(server_info));

    server_info.sin_family = AF_INET;
    server_info.sin_port = htons(port);
    server_info.sin_addr.s_addr = inet_addr("127.0.0.1");

    connect(id, (struct sockaddr *)&server_info, sizeof(server_info));

    send(id, new_value, sizeof(int) * (size + 1), 0);

    int mod = 0;
    recv(id, &mod, sizeof(int), 0);

    // printf("values are: ");
    // for (int i = 0; i <= size; i++)
    // {
    //     printf("%d ", new_value[i]);
    // }

    printf("Modulo of values: %d\n", mod);
}

int main()
{
    char input[20];
    char operator[5];
    int values[10] = {0};
    int n = 0;
    printf("Usage: 24 -+/ 12\n\n");
    printf("Enter the values with operators: ");
    scanf("%[^\n]", input);

    convert_string_number_and_operator(input, operator, values, &n);

    int size = strlen(operator);

    printf("Operators are: ");
    for (int i = 0; i < size; i++)
    {
        printf("%c ", operator[i]);
    }
    printf("\n");

    printf("Integer values are: ");
    for (int i = 0; i < n; i++)
    {
        printf("%d ", values[i]);
    }
    printf("\n");

    int operate_port[n];

    int sock_id = socket(AF_INET, SOCK_STREAM, 0);
    if (sock_id == -1)
    {
        perror("create socket: ");
        return -1;
    }

    struct sockaddr_in server_info;

    server_info.sin_family = AF_INET;
    server_info.sin_port = htons(1026);
    server_info.sin_addr.s_addr = inet_addr("127.0.0.1");

    connect(sock_id, (struct sockaddr *)&server_info, sizeof(server_info));

    send(sock_id, operator, strlen(operator), 0);

    int ports[size];

    recv(sock_id, ports, sizeof(int) * size, 0);

    printf("Ports for operators: ");

    for (int i = 0; i < size; i++)
    {
        printf("%d ", ports[i]);
    }
    printf("\n");

    for (int i = 0; i < size; i++)
    {
        if (operator[i] == '+')
        {
            sum_of_the_elements(n, values, ports[i]);
        }
        else if (operator[i] == '-')
        {
            sub_of_the_elements(n, values, ports[i]);
        }
        else if (operator[i] == '*')
        {
            mul_of_the_elements(n, values, ports[i]);
        }
        else if (operator[i] == '/')
        {
            div_of_the_elements(n, values, ports[i]);
        }
        else if (operator[i] == '%')
        {
            mod_of_the_elements(n, values, ports[i]);
        }
    }

    return 0;
}