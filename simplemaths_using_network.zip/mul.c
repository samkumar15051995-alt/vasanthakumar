#include <stdio.h>
#include <sys/socket.h>
#include <netinet/ip.h>
#include <netinet/in.h>
#include <arpa/inet.h>

int main()
{
    int mul = 1;
    int values[10] = {0};
    int server = socket(AF_INET, SOCK_STREAM, 0);
    if (server == -1)
    {
        perror("Sum server: ");
        return -1;
    }

    struct sockaddr_in server_info;

    server_info.sin_family = AF_INET;
    server_info.sin_port = htons(2003);
    server_info.sin_addr.s_addr = inet_addr("127.0.0.1");

    bind(server, (struct sockaddr *)&server_info, sizeof(server_info));

    listen(server, 5);

    int join = accept(server, NULL, NULL);
    if (join == -1)
    {
        perror("server accept: ");
        return -1;
    }

    recv(join, values, sizeof(int) * 10, 0);
    int size = values[0];

    for (int i = 1; i <= size; i++)
    {
        mul *= values[i];
    }

    send(join, &mul, sizeof(int), 0);

    printf("Multiply value returned to cliend: %d\n", mul);

    return 0;
}